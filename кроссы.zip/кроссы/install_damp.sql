-- phpMyAdmin SQL Dump
-- version 4.0.10.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Фев 14 2017 г., 11:45
-- Версия сервера: 5.1.73-cll-lve
-- Версия PHP: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `u3748_wer`
--

-- --------------------------------------------------------

--
-- Структура таблицы `custom_fields`
--

CREATE TABLE IF NOT EXISTS `custom_fields` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `options` varchar(2000) NOT NULL,
  `required` int(11) NOT NULL,
  `profile` int(11) NOT NULL,
  `edit` int(11) NOT NULL,
  `help_text` varchar(500) NOT NULL,
  `register` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `email_templates`
--

CREATE TABLE IF NOT EXISTS `email_templates` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `email_templates`
--

INSERT INTO `email_templates` (`ID`, `title`, `message`) VALUES
(1, 'Forgot Your Password', 'Dear [NAME],\r\n<br /><br />\r\nSomeone (hopefully you) requested a password reset at [SITE_URL].\r\n<br /><br />\r\nTo reset your password, please follow the following link: [EMAIL_LINK]\r\n<br /><br />\r\nIf you did not reset your password, please kindly ignore  this email.\r\n<br /><br />\r\nYours, <br />\r\n[SITE_NAME]'),
(2, 'Email Activation', 'Dear [NAME],\r\n<br /><br />\r\nSomeone (hopefully you) has registered an account on [SITE_NAME] using this email address.\r\n<br /><br />\r\nPlease activate the account by following this link: [EMAIL_LINK]\r\n<br /><br />\r\nIf you did not register an account, please kindly ignore  this email.\r\n<br /><br />\r\nYours, <br />\r\n[SITE_NAME]');

-- --------------------------------------------------------

--
-- Структура таблицы `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `pay_method` text CHARACTER SET utf8 NOT NULL,
  `transaction` text CHARACTER SET utf8 NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  `amount` text CHARACTER SET utf8 NOT NULL,
  `email` text CHARACTER SET utf8 NOT NULL,
  `comment` text CHARACTER SET utf8 NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `status` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT 'В обработке',
  `img` varchar(100) CHARACTER SET utf8 NOT NULL,
  `label` varchar(100) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `ID_2` (`ID`),
  KEY `ID` (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=159 ;

-- --------------------------------------------------------

--
-- Структура таблицы `home_stats`
--

CREATE TABLE IF NOT EXISTS `home_stats` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `google_members` int(11) NOT NULL DEFAULT '0',
  `facebook_members` int(11) NOT NULL DEFAULT '0',
  `twitter_members` int(11) NOT NULL DEFAULT '0',
  `total_members` int(11) NOT NULL DEFAULT '0',
  `new_members` int(11) NOT NULL DEFAULT '0',
  `active_today` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `home_stats`
--

INSERT INTO `home_stats` (`ID`, `google_members`, `facebook_members`, `twitter_members`, `total_members`, `new_members`, `active_today`, `timestamp`) VALUES
(1, 0, 0, 0, 1, 0, 1, 1486995502);

-- --------------------------------------------------------

--
-- Структура таблицы `ipn_log`
--

CREATE TABLE IF NOT EXISTS `ipn_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `data` text,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `IP` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ip_block`
--

CREATE TABLE IF NOT EXISTS `ip_block` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IP` varchar(500) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `reason` varchar(1000) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Структура таблицы `login_attempts`
--

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IP` varchar(500) NOT NULL DEFAULT '',
  `username` varchar(500) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `login_attempts`
--

INSERT INTO `login_attempts` (`ID`, `IP`, `username`, `count`, `timestamp`) VALUES
(1, '185.23.83.180', 'saxocredit@yandex.ru', 1, 1487000356),
(2, '185.23.83.180', 'цуа', 1, 1487001976);

-- --------------------------------------------------------

--
-- Структура таблицы `password_reset`
--

CREATE TABLE IF NOT EXISTS `password_reset` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `token` varchar(255) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `IP` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `password_reset`
--

INSERT INTO `password_reset` (`ID`, `userid`, `token`, `timestamp`, `IP`) VALUES
(2, 1, '670d6e0710c3d7903257606264b494bc6896c0e9', 1487002464, '185.23.83.180');

-- --------------------------------------------------------

--
-- Структура таблицы `payment_logs`
--

CREATE TABLE IF NOT EXISTS `payment_logs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `email` varchar(500) NOT NULL DEFAULT '',
  `processor` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `payment_plans`
--

CREATE TABLE IF NOT EXISTS `payment_plans` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `hexcolor` varchar(6) NOT NULL DEFAULT '',
  `fontcolor` varchar(6) NOT NULL DEFAULT '',
  `cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `days` int(11) NOT NULL DEFAULT '0',
  `sales` int(11) NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `payment_plans`
--

INSERT INTO `payment_plans` (`ID`, `name`, `hexcolor`, `fontcolor`, `cost`, `days`, `sales`, `description`, `icon`) VALUES
(2, 'BASIC', '65E0EB', 'FFFFFF', '3.00', 30, 8, 'This is the basic plan which gives you a introduction to our Premium Plans', 'glyphicon glyphicon-heart-empty'),
(3, 'Professional', '55CD7B', 'FFFFFF', '7.99', 90, 3, 'Get all the benefits of basic at a cheaper price and gain content for longer.', 'glyphicon glyphicon-piggy-bank'),
(4, 'LIFETIME', 'EE5782', 'FFFFFF', '300.00', 0, 1, 'Become a premium member for life and have access to all our premium content.', 'glyphicon glyphicon-gift');

-- --------------------------------------------------------

--
-- Структура таблицы `pay_link`
--

CREATE TABLE IF NOT EXISTS `pay_link` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `prefix` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT 'INV',
  `name` text CHARACTER SET utf8 NOT NULL,
  `price` text CHARACTER SET utf8 NOT NULL,
  `link` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_2` (`ID`),
  KEY `ID` (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

-- --------------------------------------------------------

--
-- Структура таблицы `reset_log`
--

CREATE TABLE IF NOT EXISTS `reset_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IP` varchar(500) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Структура таблицы `site_layouts`
--

CREATE TABLE IF NOT EXISTS `site_layouts` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `layout_path` varchar(500) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `site_layouts`
--

INSERT INTO `site_layouts` (`ID`, `name`, `layout_path`) VALUES
(1, 'Basic', 'layout/layout.php'),
(2, 'Titan', 'layout/titan_layout.php');

-- --------------------------------------------------------

--
-- Структура таблицы `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(500) NOT NULL,
  `site_desc` varchar(500) NOT NULL,
  `upload_path` varchar(500) NOT NULL,
  `upload_path_relative` varchar(500) NOT NULL,
  `site_email` varchar(500) NOT NULL,
  `site_logo` varchar(1000) NOT NULL DEFAULT 'logo.png',
  `register` int(11) NOT NULL,
  `disable_captcha` int(11) NOT NULL,
  `date_format` varchar(25) NOT NULL,
  `avatar_upload` int(11) NOT NULL DEFAULT '1',
  `file_types` varchar(500) NOT NULL,
  `twitter_consumer_key` varchar(255) NOT NULL,
  `twitter_consumer_secret` varchar(255) NOT NULL,
  `disable_social_login` int(11) NOT NULL,
  `facebook_app_id` varchar(255) NOT NULL,
  `facebook_app_secret` varchar(255) NOT NULL,
  `google_client_id` varchar(255) NOT NULL,
  `google_client_secret` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL,
  `paypal_email` varchar(1000) NOT NULL,
  `currency` varchar(100) NOT NULL DEFAULT 'RUB',
  `payment_enabled` int(11) NOT NULL,
  `payment_symbol` varchar(5) NOT NULL DEFAULT '$',
  `global_premium` int(11) NOT NULL,
  `install` int(11) NOT NULL DEFAULT '1',
  `login_protect` int(11) NOT NULL,
  `activate_account` int(11) NOT NULL,
  `default_user_role` int(11) NOT NULL,
  `secure_login` int(11) NOT NULL,
  `stripe_secret_key` varchar(1000) NOT NULL,
  `stripe_publish_key` varchar(1000) NOT NULL,
  `google_recaptcha` int(11) NOT NULL,
  `google_recaptcha_secret` varchar(255) NOT NULL,
  `google_recaptcha_key` varchar(255) NOT NULL,
  `logo_option` int(11) NOT NULL,
  `layout` varchar(500) NOT NULL,
  `card_yandex` text NOT NULL,
  `check_card_yandex` int(11) NOT NULL,
  `card_elex_visa` text CHARACTER SET ucs2 NOT NULL,
  `check_card_elex_visa` int(11) NOT NULL,
  `card_elex_mc` text NOT NULL,
  `check_card_elex_mc` int(11) NOT NULL,
  `card_qiwi` text NOT NULL,
  `check_card_qiwi` int(11) NOT NULL,
  `emoney_yandex` text NOT NULL,
  `check_emoney_yandex` int(11) NOT NULL,
  `emoney_qiwi_save` text NOT NULL,
  `check_emoney_qiwi_save` int(11) NOT NULL,
  `emoney_qiwi` text NOT NULL,
  `check_emoney_qiwi` int(11) NOT NULL,
  `emoney_paypal_rub` text NOT NULL,
  `check_emoney_paypal_rub` int(11) NOT NULL,
  `emoney_paypal_usd` text NOT NULL,
  `check_emoney_paypal_usd` int(11) NOT NULL,
  `emoney_webmoney` text NOT NULL,
  `check_emoney_webmoney` int(11) NOT NULL,
  `emoney_perfect` text NOT NULL,
  `check_emoney_perfect` int(11) NOT NULL,
  `emoney_scrill` text NOT NULL,
  `check_scrill` int(11) NOT NULL,
  `emoney_elexnet` text NOT NULL,
  `check_elexnet` int(11) NOT NULL,
  `emoney_advcash` text NOT NULL,
  `emoney_name_advcash` text NOT NULL,
  `emoney_sign_advcash` text NOT NULL,
  `check_advcash` int(11) NOT NULL,
  `emoney_btcadvcash` text NOT NULL,
  `emoney_name_btcadvcash` text NOT NULL,
  `emoney_sign_btcadvcash` text NOT NULL,
  `check_btcadvcash` int(11) NOT NULL,
  `emoney_advcash_usd` text NOT NULL,
  `emoney_name_advcash_usd` text NOT NULL,
  `emoney_sign_advcash_usd` text NOT NULL,
  `check_advcash_usd` int(11) NOT NULL,
  `emoney_btcadvcash_usd` text NOT NULL,
  `emoney_name_btcadvcash_usd` text NOT NULL,
  `emoney_sign_btcadvcash_usd` text NOT NULL,
  `check_btcadvcash_usd` int(11) NOT NULL,
  `sms_yandex` text NOT NULL,
  `check_sms_yandex` int(11) NOT NULL,
  `sms_mts` text NOT NULL,
  `check_sms_mts` int(11) NOT NULL,
  `bank_sber` text NOT NULL,
  `check_bank_sber` int(11) NOT NULL,
  `bank_rub` text NOT NULL,
  `check_bank_rub` int(11) NOT NULL,
  `bank_usd` text NOT NULL,
  `check_bank_usd` int(11) NOT NULL,
  `bank_rub_name` text NOT NULL,
  `bank_rub_corr` text NOT NULL,
  `bank_rub_bik` text NOT NULL,
  `bank_rub_inn` text NOT NULL,
  `bank_rub_account` text NOT NULL,
  `bank_rub_reciver` text NOT NULL,
  `bank_usd_name` text NOT NULL,
  `bank_usd_corr` text NOT NULL,
  `bank_usd_bik` text NOT NULL,
  `bank_usd_inn` text NOT NULL,
  `bank_usd_account` text NOT NULL,
  `bank_usd_reciver` text NOT NULL,
  `emoney_w1_usd` text NOT NULL,
  `check_w1_usd` int(11) NOT NULL,
  `emoney_w1` text NOT NULL,
  `check_w1` int(11) NOT NULL,
  `emoney_payeer` text NOT NULL,
  `check_payeer` int(11) NOT NULL,
  `emoney_payeer_usd` text NOT NULL,
  `check_payeer_usd` int(11) NOT NULL,
  `loan_api_key` text NOT NULL,
  `loan_offer` text NOT NULL,
  `loan_idsite` text NOT NULL,
  `check_loan` int(11) NOT NULL,
  `emoney_dotpay` text NOT NULL,
  `check_dotpay` int(11) NOT NULL,
  `success_url` text NOT NULL,
  `fail_url` text NOT NULL,
  `emoney_payeer_sign` text NOT NULL,
  `emoney_payeer_usd_sign` text NOT NULL,
  `admin_email` text NOT NULL,
  `mailgun_domain` text NOT NULL,
  `mailgun_api` text NOT NULL,
  `sms_id` text NOT NULL,
  `header1` text NOT NULL,
  `header2` text NOT NULL,
  `footer1` text NOT NULL,
  `footer3` text NOT NULL,
  `footer2` text NOT NULL,
  `color_left` text NOT NULL,
  `color_logo` text NOT NULL,
  `color_amount` text NOT NULL,
  `color_text` text NOT NULL,
  `color_header` text NOT NULL,
  `color_footer` text NOT NULL,
  `color_page` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `site_settings`
--

INSERT INTO `site_settings` (`ID`, `site_name`, `site_desc`, `upload_path`, `upload_path_relative`, `site_email`, `site_logo`, `register`, `disable_captcha`, `date_format`, `avatar_upload`, `file_types`, `twitter_consumer_key`, `twitter_consumer_secret`, `disable_social_login`, `facebook_app_id`, `facebook_app_secret`, `google_client_id`, `google_client_secret`, `file_size`, `paypal_email`, `currency`, `payment_enabled`, `payment_symbol`, `global_premium`, `install`, `login_protect`, `activate_account`, `default_user_role`, `secure_login`, `stripe_secret_key`, `stripe_publish_key`, `google_recaptcha`, `google_recaptcha_secret`, `google_recaptcha_key`, `logo_option`, `layout`, `card_yandex`, `check_card_yandex`, `card_elex_visa`, `check_card_elex_visa`, `card_elex_mc`, `check_card_elex_mc`, `card_qiwi`, `check_card_qiwi`, `emoney_yandex`, `check_emoney_yandex`, `emoney_qiwi_save`, `check_emoney_qiwi_save`, `emoney_qiwi`, `check_emoney_qiwi`, `emoney_paypal_rub`, `check_emoney_paypal_rub`, `emoney_paypal_usd`, `check_emoney_paypal_usd`, `emoney_webmoney`, `check_emoney_webmoney`, `emoney_perfect`, `check_emoney_perfect`, `emoney_scrill`, `check_scrill`, `emoney_elexnet`, `check_elexnet`, `emoney_advcash`, `emoney_name_advcash`, `emoney_sign_advcash`, `check_advcash`, `emoney_btcadvcash`, `emoney_name_btcadvcash`, `emoney_sign_btcadvcash`, `check_btcadvcash`, `emoney_advcash_usd`, `emoney_name_advcash_usd`, `emoney_sign_advcash_usd`, `check_advcash_usd`, `emoney_btcadvcash_usd`, `emoney_name_btcadvcash_usd`, `emoney_sign_btcadvcash_usd`, `check_btcadvcash_usd`, `sms_yandex`, `check_sms_yandex`, `sms_mts`, `check_sms_mts`, `bank_sber`, `check_bank_sber`, `bank_rub`, `check_bank_rub`, `bank_usd`, `check_bank_usd`, `bank_rub_name`, `bank_rub_corr`, `bank_rub_bik`, `bank_rub_inn`, `bank_rub_account`, `bank_rub_reciver`, `bank_usd_name`, `bank_usd_corr`, `bank_usd_bik`, `bank_usd_inn`, `bank_usd_account`, `bank_usd_reciver`, `emoney_w1_usd`, `check_w1_usd`, `emoney_w1`, `check_w1`, `emoney_payeer`, `check_payeer`, `emoney_payeer_usd`, `check_payeer_usd`, `loan_api_key`, `loan_offer`, `loan_idsite`, `check_loan`, `emoney_dotpay`, `check_dotpay`, `success_url`, `fail_url`, `emoney_payeer_sign`, `emoney_payeer_usd_sign`, `admin_email`, `mailgun_domain`, `mailgun_api`, `sms_id`, `header1`, `header2`, `footer1`, `footer3`, `footer2`, `color_left`, `color_logo`, `color_amount`, `color_text`, `color_header`, `color_footer`, `color_page`) VALUES
(1, 'BOOTPAY - прием платежей', '', '', 'uploads', '', '1f9c0301f026a6871dc2ed6baa6cf6c7.png', 0, 1, 'd/m/Y', 0, 'gif|png|jpg|jpeg', '', '', 0, '', '', '', '', 1028, '', 'RUB', 1, '$', 0, 1, 1, 0, 5, 1, '', '', 0, '', '', 0, 'layout/layout.php', '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', '', '', 0, '', '', '', 0, '', '', '', 0, '', '', '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', 0, '', 0, '', '', '', 0, '', 0, 'http://yandex.ru', 'http://yandex.ru', '', '', '', '', '', '', '', '', '', '', '', '#283142', '#7ab55c', '#7ab55c', 'rgba(255, 255, 255, 0.5)', '#d7dde4', '#ffffff', '#f0f3f6');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `token` varchar(255) NOT NULL DEFAULT '',
  `IP` varchar(500) NOT NULL DEFAULT '',
  `username` varchar(25) NOT NULL DEFAULT '',
  `first_name` varchar(25) NOT NULL DEFAULT '',
  `last_name` varchar(25) NOT NULL DEFAULT '',
  `avatar` varchar(1000) NOT NULL DEFAULT 'default.png',
  `joined` int(11) NOT NULL DEFAULT '0',
  `joined_date` varchar(10) NOT NULL DEFAULT '',
  `online_timestamp` int(11) NOT NULL DEFAULT '0',
  `oauth_provider` varchar(40) NOT NULL DEFAULT '',
  `oauth_id` varchar(1000) NOT NULL DEFAULT '',
  `oauth_token` varchar(1500) NOT NULL DEFAULT '',
  `oauth_secret` varchar(500) NOT NULL DEFAULT '',
  `email_notification` int(11) NOT NULL DEFAULT '1',
  `aboutme` varchar(1000) NOT NULL DEFAULT '',
  `points` decimal(10,2) NOT NULL DEFAULT '0.00',
  `premium_time` int(11) NOT NULL DEFAULT '0',
  `user_role` int(11) NOT NULL DEFAULT '0',
  `premium_planid` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '1',
  `activate_code` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_custom_fields`
--

CREATE TABLE IF NOT EXISTS `user_custom_fields` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_events`
--

CREATE TABLE IF NOT EXISTS `user_events` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IP` varchar(255) NOT NULL DEFAULT '',
  `event` varchar(255) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_groups`
--

CREATE TABLE IF NOT EXISTS `user_groups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `default` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `user_groups`
--

INSERT INTO `user_groups` (`ID`, `name`, `default`) VALUES
(1, 'Default Group', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `user_group_users`
--

CREATE TABLE IF NOT EXISTS `user_group_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `admin` int(11) NOT NULL DEFAULT '0',
  `admin_settings` int(11) NOT NULL DEFAULT '0',
  `admin_members` int(11) NOT NULL DEFAULT '0',
  `admin_payment` int(11) NOT NULL DEFAULT '0',
  `banned` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `user_roles`
--

INSERT INTO `user_roles` (`ID`, `name`, `admin`, `admin_settings`, `admin_members`, `admin_payment`, `banned`) VALUES
(1, 'Admin', 1, 0, 0, 0, 0),
(2, 'Member Manager', 0, 0, 1, 0, 0),
(3, 'Admin Settings', 0, 1, 0, 0, 0),
(4, 'Admin Payments', 0, 0, 0, 1, 0),
(5, 'Member', 0, 0, 0, 0, 0),
(6, 'Banned', 0, 0, 0, 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
